require 'test_helper'

module WizcmsLink
  class CategoryTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
