require 'test_helper'

module WizcmsLink
  class LinkTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
