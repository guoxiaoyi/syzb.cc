require 'test_helper'

class WizcmsLinkTest < ActiveSupport::TestCase
  test "truth" do
    assert_kind_of Module, WizcmsLink
  end
end
