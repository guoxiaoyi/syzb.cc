require 'test_helper'

module WizcmsLink
  class Admin::CategoriesHelperTest < ActionView::TestCase
  end
end
