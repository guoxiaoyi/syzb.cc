require 'test_helper'

module WizcmsLink
  class Admin::LinksHelperTest < ActionView::TestCase
  end
end
