require 'test_helper'

module WizcmsLink
  class LinksHelperTest < ActionView::TestCase
  end
end
