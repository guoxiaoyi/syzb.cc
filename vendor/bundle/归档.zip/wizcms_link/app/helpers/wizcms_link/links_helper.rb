module WizcmsLink
  module LinksHelper
  end
end
