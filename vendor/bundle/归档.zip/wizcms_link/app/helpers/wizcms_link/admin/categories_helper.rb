module WizcmsLink
  module Admin::CategoriesHelper
  end
end
