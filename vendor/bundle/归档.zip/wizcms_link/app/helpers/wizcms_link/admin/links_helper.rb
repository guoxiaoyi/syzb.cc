module WizcmsLink
  module Admin::LinksHelper
  end
end
