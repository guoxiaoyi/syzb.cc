module WizcmsLink
  class ApplicationController < ActionController::Base
  end
end
