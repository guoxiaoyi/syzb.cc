require "wizcms_link/engine"

module WizcmsLink
end
