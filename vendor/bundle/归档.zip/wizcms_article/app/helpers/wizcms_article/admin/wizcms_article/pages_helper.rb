module WizcmsArticle
  module Admin::WizcmsArticle::PagesHelper
  end
end
