module WizcmsArticle
  module Admin::WizcmsArticle::ArticlesHelper
  end
end
