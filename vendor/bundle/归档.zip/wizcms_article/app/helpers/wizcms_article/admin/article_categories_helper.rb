module WizcmsArticle
  module Admin::ArticleCategoriesHelper
  end
end
