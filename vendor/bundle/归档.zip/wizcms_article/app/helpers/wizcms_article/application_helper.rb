module WizcmsArticle
  module ApplicationHelper
  end
end
