require_dependency "wizcms_article/application_controller"

module WizcmsArticle
  class Admin::PagesController < Admin::ApplicationController
    before_action :set_page, only: [:show, :edit, :update, :destroy]

    # GET /admin/pages
    def index
      @pages = Page.all.page( params[:page] )
    end

    # GET /admin/pages/1
    def show
    end

    # GET /admin/pages/new
    def new
      @page = Page.new
    end

    # GET /admin/pages/1/edit
    def edit
    end

    # POST /admin/pages
    def create
      @page = Page.new(page_params)
      if @page.save
        redirect_to [:admin, @page], notice: 'Page was successfully created.'
      else
        render action: 'new'
      end
    end

    # PATCH/PUT /admin/pages/1
    def update
      if @page.update(page_params)
        redirect_to [:admin, @page], notice: 'Page was successfully updated.'
      else
        render action: 'edit'
      end
    end

    # DELETE /admin/pages/1
    def destroy
      @page.destroy
      redirect_to admin_pages_url, notice: 'Page was successfully destroyed.'
    end

    private
      # Use callbacks to share common setup or constraints between actions.
      def set_page
        @page = Page.find(params[:id])
      end

      # Only allow a trusted parameter "white list" through.
      def page_params
        params.require(:page).permit(:title, :content, :custom_order, :published, :cite_key, :keywords, :brief, :parent_id, :mobile_content, :picture)
      end
  end
end
