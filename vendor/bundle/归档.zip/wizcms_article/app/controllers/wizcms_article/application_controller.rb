module WizcmsArticle
  class ApplicationController < ActionController::Base
  end
end
