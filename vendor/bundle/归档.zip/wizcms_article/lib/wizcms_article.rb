require "wizcms_article/engine"
# require 'rails_kindeditor'

module WizcmsArticle
end
