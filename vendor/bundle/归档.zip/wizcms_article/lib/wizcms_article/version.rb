module WizcmsArticle
  VERSION = "0.1.6"
end
