require 'test_helper'

module WizcmsArticle
  class ArticleCategoryTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
