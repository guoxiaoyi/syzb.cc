require 'test_helper'

module WizcmsArticle
  class ArticleTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
