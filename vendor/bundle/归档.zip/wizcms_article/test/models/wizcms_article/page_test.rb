require 'test_helper'

module WizcmsArticle
  class PageTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
