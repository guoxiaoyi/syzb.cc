require 'test_helper'

class WizcmsArticleTest < ActiveSupport::TestCase
  test "truth" do
    assert_kind_of Module, WizcmsArticle
  end
end
