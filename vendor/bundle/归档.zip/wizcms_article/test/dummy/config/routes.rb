Rails.application.routes.draw do

  mount WizcmsArticle::Engine => "/"
  
end
