require 'test_helper'

module WizcmsArticle
  class Admin::WizcmsArticle::PagesHelperTest < ActionView::TestCase
  end
end
