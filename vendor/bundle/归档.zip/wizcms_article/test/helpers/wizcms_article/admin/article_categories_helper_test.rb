require 'test_helper'

module WizcmsArticle
  class Admin::ArticleCategoriesHelperTest < ActionView::TestCase
  end
end
