require 'test_helper'

module WizcmsArticle
  class Admin::WizcmsArticle::ArticlesHelperTest < ActionView::TestCase
  end
end
