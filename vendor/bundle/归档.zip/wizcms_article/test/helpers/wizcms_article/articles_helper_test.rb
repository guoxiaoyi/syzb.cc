require 'test_helper'

module WizcmsArticle
  class ArticlesHelperTest < ActionView::TestCase
  end
end
